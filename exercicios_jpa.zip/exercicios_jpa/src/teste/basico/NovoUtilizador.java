package teste.basico;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import modelo.basico.Utilizador;

public class NovoUtilizador {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("exercicios_jpa");
		EntityManager em = emf.createEntityManager();
		
		Utilizador novoUtilizador = new Utilizador("Leo", "leo@lanche.com.br");
		
		em.persist(novoUtilizador);
		
		em.close();
		emf.close();
	}
}
