package teste.basico;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import modelo.basico.Utilizador;

public class NovoUtilizador {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("exercicios-jpa");
		EntityManager em = emf.createEntityManager();
		
		Utilizador novoUtilizador = new Utilizador("Djalma", "djalma@lanche.com.br");
		
		em.persist(novoUtilizador);
		
		em.close();
		emf.close();
	}
}
